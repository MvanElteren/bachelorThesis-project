package thesisPackage;

import java.util.ArrayList;
import java.util.List;

/**
 * Class to represent a row of a probability table by its values and a
 * probability.
 * 
 * @author Marcel de Korte, Moira Berens, Djamari Oetringer, Abdullahi Ali,
 *         Leonieke van den Bulk
 */
public class ProbRow implements Comparable<ProbRow> {
	private List<String> values;
	private double prob;

	/**
	 * Constructor of the class.
	 * 
	 * @param values, values of the variables (main variable+parents) in the row, of
	 *                which the value of the main variable itself is always first.
	 * @param prob,   probability belonging to this row of values.
	 */
	public ProbRow(List<String> values, double prob) {
		this.prob = prob;
		this.values = values;
	}

	/**
	 * Transform probabilities to string.
	 */
	public String toString() {
		String valuesString = "";
		for (int i = 0; i < values.size() - 1; i++) {
			valuesString = valuesString + values.get(i) + ", ";
		}
		valuesString = valuesString + values.get(values.size() - 1);
		return valuesString + " | " + Double.toString(prob);
	}

	/**
	 * Getter of the values of this probability row.
	 * 
	 * @return List<String> of values
	 */
	public List<String> getValues() {
		return values;
	}

	/**
	 * Getter of the probability of this probability row
	 * 
	 * @return the probability as a double.
	 */
	public double getProb() {
		return prob;
	}

	/**
	 * Setter of the probability of this probability row
	 * 
	 * @param prob
	 */
	public void setProb(double prob) {
		this.prob = prob;
	}

	/**
	 * This function removes the value assignment of the ProbRow at a specific
	 * position.
	 * 
	 * @param index: of value to remove from ProbRow
	 */
	public void remove(int index) {
		values.remove(index);
	}

	/**
	 * @return a copy of the ProbRow
	 */
	public ProbRow getCopy() {
		List<String> copiedValues = new ArrayList<>(this.values);
		double copiedProb = this.prob;
		return new ProbRow(copiedValues, copiedProb);
	}

	/**
	 * This function merges two ProbRows together.
	 *
	 * @param a2
	 * @param positions
	 * @return new ProbRow by merging two together.
	 */
	public ProbRow merge(ProbRow a2, List<Integer> positions) {
		List<String> newVals = new ArrayList<>(values);
		for (int i = 0; i < a2.getValues().size(); i++) {
			// If the index is not in the given array, which contains indices of duplicate
			// variables in that ProbRow, add the value to the new value list.
			if (!positions.contains(i)) {
				newVals.add(a2.getValues().get(i));
			}
		}
		// Return the new ProbRow with all values of the distinct variables and the
		// updated probability for that row.
		return new ProbRow(newVals, prob * a2.getProb());
	}

	/**
	 * This function checks if two ProbRows have the same value assignment, except
	 * for 1 value of a variable at a specific given position.
	 *
	 * @param row
	 * @param position
	 * @return boolean: whether the value assignment is the same or not.
	 */
	public boolean isSame(ProbRow row, int position) {
		for (int i = 0; i < values.size(); i++) {
			// Check if the values in the probability rows are the same, except for the
			// specified position
			if (i != position && !values.get(i).equals(row.getValues().get(i))) {
				return false;
			}
		}
		return true;
	}

	@Override
	public int compareTo(ProbRow o) {
		if (this.getProb() < o.getProb())
			return -1;
		if (this.getProb() == o.getProb())
			return 0;
		return 1;
	}

}