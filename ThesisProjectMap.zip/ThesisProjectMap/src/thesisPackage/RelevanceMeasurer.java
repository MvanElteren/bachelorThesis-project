package thesisPackage;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Class originally written to calculate MAP-independence over some instance of
 * a Bayesian network.
 * 
 * @author Luuk Jacobs, Simon Janssen and Merlijn van Elteren
 * 
 * Later updated to also calculate quantified MAP-dependence and intrinsic
 * relevance, specifically for an instance of the ALARM network.
 * 
 * Updated by @author Merlijn van Elteren
 */
public class RelevanceMeasurer {
	private List<Variable> evidence;
	private List<Variable> hypothesis;
	private List<Variable> intermediate;
	private List<Factor> factors;
	private String heuristic;
	
	/**
	 * Constructor of the relevance measurer.
	 * 
	 * @param ui, the user interface, which contains the information we need.
	 */
	public RelevanceMeasurer(UserInterface ui) {

		// Retrieve the hypothesis set H:
		this.hypothesis = ui.getHypothesisVariables();

		// Retrieve the evidence set E:
		this.evidence = ui.getEvidenceVariables();

		// Retrieve the intermediate set I.
		this.intermediate = ui.getIntermediateVariables();

		// Create factors and immediately reduce out the evidence variables.
		this.factors = new ArrayList<>();
		for (Table t : ui.getPs()) {
			factors.add(new Factor(t.getVariable(), t.getTable()));
		}
		reduceEvidenceVariables();
		ui.setFs(new ArrayList<>(factors));

		// Set the heuristic. We could select from options using the UI if we enable the following lines
		// However, the heuristics are not really relevant to the project, so we'll just set it to fewest-factors for now.
//		ui.askForHeuristic();
//		this.heuristic = ui.getHeuristic();
		this.heuristic = "fewest-factors";
	}

	/**
	 * This function reduces each evidence variable out of all factors containing such a
	 * variable, by calling the reduce function on a factor with the given evidence
	 * variable and value.
	 */
	private void reduceEvidenceVariables() {
		for (Variable var : evidence) {
			Iterator<Factor> it = factors.iterator();
			while (it.hasNext()) {
				Factor factor = it.next();
				if (factor.containsVar(var)) {
					// If the factor only has the variable we want to reduce it will result in a
					// factor with an empty table, which is not useful, so we remove the empty
					// factor from consideration.
					if (factor.NrOfVariables() == 1) {
						it.remove();
					} else {
						factor.reduce(var, var.getObservedValue());
					}
				}
			}
		}
	}

	/**
	 * ~~~~~~~~~~THIS SECTION IS FOR MAP-INDEPENDENCE~~~~~~~~~~
	 */

	/**
	 * This function is used to calculate quantified MAP-dependence
	 * and MAP-independence for the given instance. 
	 */
	public void solveMapIndependence() {
		// First, solve MAP once without setting any intermediate variables to specific
		// values, to find the optimal value-assignment h* of the hypothesis variables.
		List<Variable> allInt = getVarListCopy(this.intermediate);
		List<String> hStar = solveMAP(getFactorListCopy(this.factors), getVarListCopy(this.hypothesis), allInt,
				heuristic);
		List<Variable> R = new ArrayList<>();
		
		// Print the header
		System.out.println("Variable \t & Q-MAPdep \t & MAP-ind ");
		
		// Then calculate quantified MAP-independence for each individual intermediate variable, as follows:
		for (int i = 0; i < intermediate.size(); i++) {
			allInt = getVarListCopy(this.intermediate);
			R.clear();
			R.add(allInt.remove(i));

			// Compute all the possible value assignments r to the intermediate variables in R.
			List<List<String>> possibleAssignments = computePossibleAssignments(getVarListCopy(R), new ArrayList<>(),
					new ArrayList<>());
			
			// Quantified MAP-dependence is calculated as the fraction of possible assignments
			// r for which the h-assignment resulting from MAP is not the same as h*.
			// This fraction is calculated as follows:
			double counter = 0;
			double total = possibleAssignments.size();
			for (List<String> assignment : possibleAssignments) {
				List<Factor> myFactors = getFactorListCopy(this.factors);
				
				// Reduce R to r in all factors containing (a variable in) R.
				reduceListOfVariables(getVarListCopy(R), assignment, myFactors);
				
				// Calculate the MAP-assignment h.
				List<String> hAssignment = solveMAP(myFactors, getVarListCopy(this.hypothesis),
						getVarListCopy(this.intermediate), heuristic);
				
				// Compare h to h*.
				if (!assignmentsEqual(hStar, hAssignment)) {
					counter += 1;
				}
			}
			double quantifiedMAPDependence = counter / total;
			
			// Print the set R.
			System.out.print("");
			for (int j = 0; j < R.size() - 1; i++) {
				System.out.print(R.get(j).getName() + ", ");
			}
			System.out.print(R.get(R.size() - 1).getName() + " \t & ");
			
			// Print out the quantified MAP-dependence of R, and also whether or not R is map-independent. 
			System.out.print(String.format("%.2f \t & ", quantifiedMAPDependence));
			if (quantifiedMAPDependence == 0.0) {
				System.out.println("YES \t & ");
			} else {
				System.out.println("NO \t & ");
			}
		}
	}

	/**
	 * ~~~~~~~~~~THIS SECTION IS FOR INTRINSIC RELEVANCE~~~~~~~~~~
	 */

	/**
	 * This function is used to calculate intrinsic relevance for the given instance. 
	 */
	public void solveIntrinsicRelevance() {
		List<Variable> allInt;
		List<Variable> R = new ArrayList<>();
		
		// Print the header
		System.out.println("Variable \t & int-rel ");
		
		// Calculate intrinsic relevance for each individual intermediate variable, as follows:
		for (int i = 0; i < intermediate.size(); i++) {
			allInt = getVarListCopy(this.intermediate);
			R.clear();
			R.add(allInt.remove(i));
			
			// Compute all the possible value assignments I to the intermediate variables in I.
			List<List<String>> possibleAssignmentsOfI = computePossibleAssignments(getVarListCopy(allInt),
					new ArrayList<>(), new ArrayList<>());
			
			// Compute all the possible value assignments r to the intermediate variables in R
			List<List<String>> possibleAssignmentsOfR = computePossibleAssignments(getVarListCopy(R),
					new ArrayList<>(), new ArrayList<>());
			
			// Intrinsic relevance is calculated as the fraction of possible assignments i
			// for which the h-assignment resulting from MAP is not the same for every
			// possible assignment r.
			double counter = 0;
			double total = possibleAssignmentsOfI.size();
			for (List<String> assignmentOfI : possibleAssignmentsOfI) {
				// Reduce I to i in all factors containing (a variable in) I.
				List<Factor> factorsReducedI = getFactorListCopy(this.factors);
				reduceListOfVariables(getVarListCopy(allInt), assignmentOfI, factorsReducedI);
	
				// We calculate the first assignment hFirst to H, to which we will compare all other assignments:
				List<Factor> factorsReducedIAndR = getFactorListCopy(factorsReducedI);
				// Reduce R to r in all factors containing (a variable in) R.
				reduceListOfVariables(getVarListCopy(R), possibleAssignmentsOfR.get(0), factorsReducedIAndR);
				// Calculate hFirst.
				List<String> hFirst = solveMAP(factorsReducedIAndR, getVarListCopy(this.hypothesis),
						getVarListCopy(allInt), heuristic);
	
				// We calculate other assignments (hOther) to H and compare them to hFirst.
				for (int j = 1; j < possibleAssignmentsOfR.size(); j++) {
					factorsReducedIAndR = getFactorListCopy(factorsReducedI);
					// Reduce R to r in all factors containing (a variable in) R.
					reduceListOfVariables(getVarListCopy(R), possibleAssignmentsOfR.get(j), factorsReducedIAndR);
					// Calculate hOther.
					List<String> hOther = solveMAP(factorsReducedIAndR, getVarListCopy(this.hypothesis),
							getVarListCopy(allInt), heuristic);
					
					// Compare hOther to hFirst.
					if (!assignmentsEqual(hOther, hFirst)) {
						counter += 1;
						break;
					}
				}
	
			}
			double intrinsicRelevance = counter / total;
			
			// Print the set R.
			System.out.print("");
			for (int j = 0; j < R.size() - 1; i++) {
				System.out.print(R.get(j).getName() + ", ");
			}
			System.out.print(R.get(R.size() - 1).getName() + " \t & ");
			
			// Print out the quantified MAP-dependence of R, and also whether or not R is map-independent. 
			System.out.println(String.format("%.2f", intrinsicRelevance));
		}
	}

	/**
	 * ~~~~~~~~~~THIS SECTION IS FOR ALL OTHER FUNCTIONS~~~~~~~~~~
	 */
	
	/**
	 * Checks whether two value assignments are equal.
	 * 
	 * @param h1, a value assignment.
	 * @param h2, an other value assignment.
	 * @return a boolean indicating whether the assignments are equal.
	 */
	private boolean assignmentsEqual(List<String> h1, List<String> h2) {
		if (h1.size() != h2.size()) {
			System.out.println("THESE ASSIGNMENTS ARE NOT EVEN OF EQUAL SIZE");
			return false;
		}
		for (int i = 0; i < h1.size(); i++) {
			if (!h1.get(i).equals(h2.get(i))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Reduces each variable of a list of variables out of all factors containing such
	 * a variable, by calling the reduce function.
	 * 
	 * @param theList the list of variables to be reduced.
	 * @param assignment, a list of strings indicating values to assign to the variables.
	 * @param factors, a list of factors out of which we want to reduce away the variables.
	 */
	private void reduceListOfVariables(List<Variable> theList, List<String> assignment, List<Factor> factors) {
		for (int i = 0; i < theList.size(); i++) {
			Variable var = theList.get(i);
			Iterator<Factor> it = factors.iterator();
			while (it.hasNext()) {
				Factor factor = it.next();
				if (factor.containsVar(var)) {
					// If the factor only has the variable we want to reduce it will result in a factor
					// with an empty table, which is not useful, so we remove the empty factor
					// from consideration.
					if (factor.NrOfVariables() == 1) {
						it.remove();
					} else {
						factor.reduce(var, assignment.get(i));
					}
				}
			}
		}
	}

	/**
	 * This function starts the variable elimination procedure to compute the most
	 * likely joint value assignment over the variables of interest (hypotheses).
	 *
	 * @param factors, the list of factors.
	 * @param hypothesis, the list of hypothesis variables H.
	 * @param intermediate, the list of intermediate variables I.
	 * @param heuristic, the chosen heuristic as a string.
	 */
	private List<String> solveMAP(List<Factor> factors, List<Variable> hypothesis, List<Variable> intermediate, String heuristic) {
		// Decide upon an elimination order for the intermediate variables
		// using the given heuristic.
		Heuristic h = new Heuristic(heuristic);
		List<Variable> order = h.apply(intermediate, factors);
		
		// Eliminate the intermediate variables I.
		for (int i = 0; i < order.size(); i++) {
			Variable varToMarginalize = order.get(i);
			eliminateVariable(varToMarginalize, factors);
			intermediate.remove(varToMarginalize);
		}
		
		// Fix a maximization ordering, using the fewest-factors heuristic.
		Heuristic h2 = new Heuristic("fewest-factors");
		List<Variable> maxOrdering = h2.apply(hypothesis, factors);
		
		// Compute the MAP joint value assignment to H.
		maximizeVariables(maxOrdering, factors);
		
		// Return the resulting joint value assignment.
		List<String> result = new ArrayList<>();
		for (Variable hyp : hypothesis) {
			result.add(hyp.getBestValue());
		}
		return result;
	}

	/**
	 * This function eliminates a given variable from all the factors containing it.
	 * First it checks which factors contain the variable. If more than two factors
	 * contain the variable they will be multiplied together according to the
	 * multiply function in Factor. Lastly the variable will be marginalised and
	 * therefore eliminated. If the resulting factors still contains variables, it
	 * will be added to the factors list again as a new factor.
	 *
	 * @param var, variable to eliminate
	 */
	private void eliminateVariable(Variable var, List<Factor> factors) {
		// Check in which factors the variable is contained and add those to a new ArrayList.
		List<Factor> containVar = containedIn(var, factors);
		if (!containVar.isEmpty()) {
			// Multiply the factors that contain the variable until there is only one factor
			// left.
			Factor res = computeProduct(containVar, false);
			// Marginalise out the variable from the factor and add it to the list if the
			// factor still contains variables.
			Factor result = res.marginalize(var);
			if (result.NrOfVariables() > 0) {
				factors.add(result);
			}
		}
	}

	/**
	 * This function checks in which factors the variable is contained. It adds
	 * those to a new ArrayList, and removes them from the list given in the input.
	 *
	 * @param v
	 * @param factors
	 * @return an List of factors in which variable v is contained.
	 */
	private List<Factor> containedIn(Variable v, List<Factor> factors) {
		List<Factor> containVar = new ArrayList<>();
		Iterator<Factor> it = factors.iterator();
		// Check in which factors the variable is contained and add those to a new
		// ArrayList.
		while (it.hasNext()) {
			Factor factor = it.next();
			if (factor.containsVar(v)) {
				containVar.add(factor);
				it.remove();
			}
		}
		return containVar;
	}

	/**
	 * This function computes the product in a list of factors.
	 *
	 * @param factors
	 * @param preserve, determines whether or not to preserve the original factor
	 *                  list.
	 * @return result of taking a product between a list of factors.
	 */
	private Factor computeProduct(List<Factor> factors, boolean preserve) {
		// If the original factors need to be preserved:
		if (preserve) {
			// Create a new copy of the first factor
			Factor result = new Factor(factors.get(0));
			int i = 1;
			// While there are other factors, do the product between the result and the
			// factor
			while (factors.size() > i) {
				Factor fac = factors.get(i);
				result = result.product(fac);
				i++;
			}
			// Return the result.
			return result;
			// If the original factors do not need to be preserved:
		} else {
			// Compute the product between two factors and put back the resulting factor in
			// the list.
			while (factors.size() > 1) {
				Factor f1 = factors.remove(0);
				Factor f2 = factors.remove(0);
				factors.add(f1.product(f2));
			}
			// If there is only one factor left, this is the result which can be returned.
			return factors.get(0);
		}
	}

	/**
	 * This function computes the best value for each variable. It does so by
	 * applying the argmax operation on the factors containing the hypothesis
	 * variables.
	 *
	 * @param ordering
	 * @param factors
	 */
	private void maximizeVariables(List<Variable> ordering, List<Factor> factors) {
		// Check if there are multiple hypothesis variables.
		if (ordering.size() > 1) {
			Variable var = ordering.remove(0);
			// Add factors containing variable to a new ArrayList and remove them from the
			// original list.
			List<Factor> containVar = containedIn(var, factors);
			// Multiply the factors that contain the variable until there is only one factor
			// left.
			Factor result = computeProduct(containVar, true);
			// Maximize over the resulting factor and add it to the factors list.
			result = result.maximize(var);
			factors.add(result);
			// Make a duplicate of the current ordering.
			List<Variable> myOrdering = new ArrayList<Variable>(ordering);
			// Recurse to get the assignments of the next variables in the ordering.
			maximizeVariables(ordering, factors);
			// Reduce the factors to the values of the other variables later in the
			// ordering.
			for (int j = 0; j < myOrdering.size(); j++) {
				Variable hyp = myOrdering.get(j);
				for (Factor f : containVar) {
					if (f.containsVar(hyp)) {
						f.reduce(hyp, hyp.getBestValue());
					}
				}
			}
			// Multiply the reduced factors.
			Factor res = computeProduct(containVar, false);
			// Do an argmax on the resulting factor
			String bestValue = res.argmax();
			var.setBestValue(bestValue);
			// Return.
			return;
		} else if (ordering.size() == 1) {
			Variable var = ordering.remove(0);
			List<Factor> containVar = containedIn(var, factors);
			Factor result = computeProduct(containVar, false);
			// Do an argmax on the resulting factor
			String bestValue = result.argmax();
			var.setBestValue(bestValue);
			// If you have an empty factor, return.
			return;
		} else {
			System.err.println("No hypothesis variables! Something went wrong.");
			return;
		}
	}
	
	/**
	 * A recursive function used to calculate (and return) all possible value assignments v to a list V of variables.
	 * @param varList, the list of variables
	 * @param result, needed due to recursive nature
	 * @param assignment, needed due to recursive nature.
	 * @return A list containing all possible value assignments v.
	 */
	private List<List<String>> computePossibleAssignments(List<Variable> varList, List<List<String>> result,
			List<String> assignment) {
		Variable v = varList.remove(0);
		for (String value : v.getValues()) {
			assignment.add(value);
			List<String> copy = new ArrayList<>(assignment);
			if (varList.isEmpty()) {
				result.add(copy);
			} else {
				List<Variable> vars = new ArrayList<>(varList);
				computePossibleAssignments(vars, result, copy);
			}
			assignment.remove(assignment.size() - 1);
		}
		return result;
	}

	/**
	 * A function which returns a new copy of an original list of variables.
	 * @param original, the original list of variables.
	 * @return The new copy; not a copy by reference.
	 */
	private List<Variable> getVarListCopy(List<Variable> original) {
		List<Variable> result = new ArrayList<>(original);
		return result;
	}

	/**
	 * A function which returns a new copy of an original list of factors.
	 * @param original, the original list of factors.
	 * @return The new copy; not a copy by reference.
	 */
	private List<Factor> getFactorListCopy(List<Factor> original) {
		List<Factor> result = new ArrayList<>();
		for (Factor f : original) {
			result.add(new Factor(f));
		}
		return result;
	}
}
