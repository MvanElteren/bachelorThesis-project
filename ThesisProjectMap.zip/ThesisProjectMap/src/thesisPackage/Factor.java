package thesisPackage;

import java.util.List;
import java.util.ListIterator;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 * Class to represent a factor of a probability table on which computations can
 * be performed.
 *
 * @author Simon Janssen and Jonathan Bauermeister
 * 
 * Updated by @author Merlijn van Elteren
 */
public class Factor extends Table {

	private List<Variable> vars = new ArrayList<>();

	/**
	 * Constructor of the class.
	 * 
	 * @param v,     variable belonging to the current probability table and factor.
	 * @param table, table made out of probability rows (ProbRows).
	 */
	public Factor(Variable v, List<ProbRow> table) {
		super(v, table);
		vars.add(v);
		if (v.getNrOfParents() > 0) {
			vars.addAll(getParents());
		}
	}

	/**
	 * Constructor of the class.
	 * 
	 * @param vars, variables that are in the factor.
	 * @param var,  variable belonging to the probability table and factor.
	 */
	public Factor(List<Variable> vars, Variable var) {
		this.vars = vars;
		setVariable(var);
	}

	/**
	 * Constructor of the class.
	 * 
	 * @param original
	 */
	public Factor(Factor original) {
		super(original.getVariable(), original.getTableCopy());
		this.vars = new ArrayList<>(original.getVars());
	}

	/**
	 * This function returns all variables that are contained in the factor.
	 * 
	 * @return all variables in the factor
	 */
	public List<Variable> getVars() {
		return vars;
	}

	/**
	 * @return the number of variables the factor contains.
	 */
	public int NrOfVariables() {
		return vars.size();
	}

	/**
	 * This function returns a boolean whether or not a given variable is contained
	 * in the factor
	 * 
	 * @param variable
	 * @return boolean whether or not the variable is contained in the factor
	 */
	public boolean containsVar(Variable variable) {
		return vars.contains(variable);
	}

	/**
	 * This function returns the position of the variable in the table (which column
	 * has the values of that variable).
	 * 
	 * @param v: The variable
	 * @return position of variable in the table.
	 */
	public int position(Variable v) {
		return vars.indexOf(v);
	}

	/**
	 * Returns a list of probability rows with the same assignment for a specified
	 * variable.
	 * 
	 * @param rows
	 * @param assignment
	 * @param position
	 * @return list of assignments where the value assignment for the specified
	 *         position is the same as in @param assignment.
	 */
	public List<Integer> getSameAssignments(List<ProbRow> rows, ProbRow assignment, int position) {
		List<Integer> sameAssignments = new ArrayList<>();
		for (int i = 0; i < rows.size(); i++) {
			ProbRow row = rows.get(i);
			if (assignment.isSame(row, position)) {
				sameAssignments.add(i);
			}
		}
		return sameAssignments;
	}

	/**
	 * This function sums out a specified variable from the table and computes a new
	 * factor without that variable in it.
	 *
	 * @param v: the variable that needs to be summed out.
	 * @return the new factor with the variable summed out.
	 */
	public Factor marginalize(Variable v) {
		// Get the current table.
		List<ProbRow> rows = getTable();
		// Create a new probability table.
		List<ProbRow> newTable = new ArrayList<>();

		System.gc();

		int positionOfVariable = position(v); // The position of v in this.vars
		int nrOfValues = v.getNrOfValues(); // The number of values v could take on
		int countUntil = rows.size(); // We want to work our way through the entire list of rows.

		// Calculate the interval at which we find assignments with the same values
		// other than the value of v.
		// This is done by finding the first assignment for which this condition is true
		// with relation to the first row.
		// Due to the way we construct all factors, this interval is the same for ALL
		// rows.
		int interval = -1;
		ProbRow assignment = rows.get(0);
		for (int i = 1; i < countUntil; i++) {
			if (assignment.isSame(rows.get(i), positionOfVariable)) {
				interval = i;
				break;
			}
		}

		// We loop over the entirety of the list of rows.
		int index = 0; // Keeps track of the index, like a for-loop, but it is updated differently than
						// just index++.
		int stepsSinceLastJump = 0; // Used to keep track of when the index should "jump" (see below how index is
									// updated).
		while (index < countUntil) {

			// Get the row for which we want to find the other rows with the same assignment
			// other than the value of v.
			assignment = rows.get(index);
			// Also get its probability
			double prob = assignment.getProb();

			// Get rows with the same assignment other than the value of v
			// and calculate the total probability for all these rows.
			for (int i = 1; i < nrOfValues; i++) {
				ProbRow row = rows.get(index + interval * i);
				prob += row.getProb();
				rows.set(index + interval * i, null);
			}

			// Make a new probability row with the variable marginalised out,
			// and with the new probability (the sum of the probabilities of the previous
			// rows).
			ProbRow newA = new ProbRow(assignment.getValues(), prob);
			if (newA.getValues().size() > 1) {
				newA.remove(position(v));
			}
			rows.set(index, null);

			// Add the new row to the new table.
			newTable.add(newA);

			// We always increment the index by 1, a "step"...
			index++;
			stepsSinceLastJump++;

			// However, if stepsSinecLastJump is equal to the interval, we arrive at a row
			// we have already combined with.
			// In that case, we need to "jump", by incrementing the index by
			// (v.getNrOfValues()-1)*interval,
			// in order to set our index at the position of the next row we haven't done
			// anything with yet.
			if (stepsSinceLastJump == interval) {
				stepsSinceLastJump = 0;
				index += (v.getNrOfValues() - 1) * interval;
			}
		}
		// Remove v from the variable list, and set the probability table to
		// the newly-computed probability table.
		setTable(newTable);
		vars.remove(v);
		return this;
	}

	/**
	 * This function maximises over a specified variable in a factor and computes a
	 * new factor without the variable.
	 *
	 * @param v
	 * @return the new factor with the variable maximised out.
	 */
	public Factor maximize(Variable v) {
		// Make sure that the variable is indeed included in the factor
		if (!containsVar(v)) {
			return null;
		}
		// Create new probability table.
		List<ProbRow> newTable = new ArrayList<>();
		// Make a duplicate of the table.
		List<ProbRow> rows = getTable();
		// While there are still rows left, get the first assignment
		while (rows.size() > 0) {
			ProbRow assignment = rows.remove(0);
			// Get rows with the same assignment, except for the variable that you want to
			// maximize.
			List<Integer> sameAssignments = getSameAssignments(rows, assignment, position(v));
			// Get the row with the maximum probability.
			ProbRow maxRow = assignment;
			int counter = 0;
			for (Integer newRow : sameAssignments) {
				if (maxRow.getProb() < rows.get(newRow - counter).getProb()) {
					maxRow = rows.get(newRow - counter);
				}
				rows.remove(newRow - counter++);
			}
			// Make a new probability row with the variable and values marginalised out and
			// with the new probability.
			if (maxRow.getValues().size() > 1) {
				maxRow.remove(position(v));
			}
			newTable.add(maxRow);
		}
		// Remove the variable from the variable list and set the probability table to
		// the new computed probability table.
		setTable(newTable);
		vars.remove(v);
		return this;
	}

	/**
	 * @return the value of a variable in the factor for which the probability is
	 *         maximal.
	 */
	public String argmax() {
		// Normalise the factor to get a probability distribution (for visualisation
		// purposes).
		this.normalize();
		// Create a map to extract the value
		HashMap<Double, String> dict = new HashMap<Double, String>();
		for (ProbRow row : this.getTable()) {
			dict.put(row.getProb(), row.getValues().get(0));
		}
		// Locate the maximal probability.
		double maxProb = Collections.max(dict.keySet());
		// Return the value for which the probability is maximal.
		return dict.get(maxProb);
	}

	/**
	 * This function computes the new factor when a factor is reduced by a given
	 * variable that takes on a given value.
	 *
	 * @param v:     Variable that needs to be reduced.
	 * @param value: value that the variable takes on.
	 * @return new factor with the variable reduced to the specific value
	 */
	public Factor reduce(Variable v, String value) {
		// Make sure that the variable is indeed included in the factor
		if (!containsVar(v)) {
			return null;
		}
		// Create new probability table.
		List<ProbRow> newTable = new ArrayList<>();
		// For every assignment in the table
		for (ProbRow assignment : getTable()) {
			// If the value for the variable that you want to reduce equals the specified
			// value
			if (assignment.getValues().get(position(v)).equals(value)) {
				// Create a new probability row without that variable and with the same
				// probability
				ProbRow newA = new ProbRow(assignment.getValues(), assignment.getProb());
				if (newA.getValues().size() > 1) {
					newA.remove(position(v));
				}
				newTable.add(newA);
			}
		}
		// Remove the variable from the variable list and set the probability table to
		// the new computed probability table.
		setTable(newTable);
		vars.remove(v);
		return this;
	}

	/**
	 * This function computes the product of two specified factors.
	 *
	 * @param f: factor that gets multiplied.
	 * @return new factor: result of multiplication of the two factors.
	 */
	public Factor product(Factor f) {
		// Create an List for variables that are both in factor 1 and in factor 2.
		List<Variable> commonVars = new ArrayList<>();
		// Create an List for all different variables that are either in factor 1 or in
		// factor 2.
		List<Variable> allVars = new ArrayList<>(vars);
		// Create an List that keeps track of the positions of the common variables in
		// the tables for the second factor.
		List<Integer> positions = new ArrayList<>();

		// Add the variables of both factors to the appropriate lists.
		for (Variable v : f.getVars()) {
			if (allVars.contains(v)) {
				commonVars.add(v);
				positions.add(f.position(v));
			} else {
				allVars.add(v);
			}
		}

		List<ProbRow> ourTable = getTable();
		List<ProbRow> theirTable = f.getTable();
		List<ProbRow> newTable = new ArrayList<>();
		Factor newF = new Factor(allVars, getVariable());

		boolean lastFactor = ourTable.size() > 15000000; // Check whether this is the last factor-calculation of
																// the full input-calculation for ALARM.
		double sum = 0; // Used to normalise the resulting factor, so it is a probability distribution.

		for (int i = 0; i < ourTable.size(); i++) {
			ProbRow a1 = ourTable.get(i); // Row from factor 1

			for (int j = 0; j < theirTable.size(); j++) {
				ProbRow a2 = theirTable.get(j); // Row from factor 2

				// Check that the common variables have the same assignment in both rows.
				boolean same = true;
				if (commonVars.size() > 0) {
					for (Variable common : commonVars) {
						if (!a1.getValues().get(position(common)).equals(a2.getValues().get(f.position(common)))) {
							same = false;
						}
					}
				}

				// If the common variables have the same assignments in both rows, merge the
				// variable assignments
				// of the two assignments into 1 new single assignment and calculate its
				// probability
				if (same) {
					ProbRow newA = a1.merge(a2, positions);
					sum += newA.getProb();
					newTable.add(newA);

					// If we're in the last factor of the full input-calculation for the 16 evidence
					// variables of
					// the ALARM network, then we only keep the 100 most likely value assignments,
					// and already order them based on descending probability.
					if (lastFactor && newTable.size() > 100) {
						Collections.sort(newTable);
						Collections.reverse(newTable);
						newTable.remove(100);
					}
				}
			}
			ourTable.set(i, null); // Saves memory while running on a big factor.
		}

		// Normalise each probability in the table.
		for (int i = 0; i < newTable.size(); i++) {
			ProbRow row = newTable.get(i);
			row.setProb(row.getProb() / sum);
		}
		// Update the probability table and return the factor.
		newF.setTable(newTable);
		return newF;
	}

	/**
	 * This function normalises the factor by making sure it is a probability
	 * distribution again. The total probability of the table should sum to 1, so
	 * each probability in the table gets divided by the total probability of the
	 * table.
	 * 
	 * @return normalised factor
	 */
	public Factor normalize() {
		double sum = 0;

		// Calculate the total probability in the variable table
		for (ProbRow row : getTable()) {
			sum += row.getProb();
		}

		// Normalise each probability from the table
		for (int i = 0; i < getTable().size(); i++) {
			ProbRow row = getTable().get(i);
			row.setProb(row.getProb() / sum);
		}
		return this;
	}

	/**
	 * This function orders the probability-rows based on their probabilities.
	 * 
	 * @return
	 */
	public Factor orderOnProb() {
		List<ProbRow> table = getTable();
		Collections.sort(table);
		Collections.reverse(table);
		this.setTable(table);
		return this;
	}

	/**
	 * This function makes a large string as a representation of the factor.
	 * 
	 * @return full string of variables in factor and probability table
	 */
	public String toString() {
		String tableString = "f( ";
		for (int i = 0; i < vars.size(); i++) {
			if (i < vars.size() - 1) {
				tableString = tableString + vars.get(i).getName() + ", ";
			} else {
				tableString += vars.get(i).getName() + " ";
			}
		}
		tableString += ")";
		for (ProbRow row : getTable()) {
			tableString = tableString + "\n" + row.toString();
		}
		return tableString + "\n";
	}

	/**
	 * This function makes a shorthand version of the factor into a string, in the
	 * form 'f(A,B,C)' where A, B and C are variables
	 * 
	 * @return string of factor representation
	 */
	public String shortString() {
		String tableString = "f( ";
		for (int i = 0; i < vars.size(); i++) {
			if (i == vars.size() - 1) {
				tableString += vars.get(i).getName();
			} else {
				tableString = tableString + vars.get(i).getName() + ", ";
			}
		}
		tableString = tableString + " )";
		return tableString;
	}
}
