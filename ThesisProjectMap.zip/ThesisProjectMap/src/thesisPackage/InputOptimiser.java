package thesisPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

/**
 * Class used to calculate the most likely input to the ALARM network.
 * 
 * @author Merlijn van Elteren
 */
public class InputOptimiser {
	private List<Variable> intermediate;
	private List<Factor> factors;
	private String heuristic;

	public InputOptimiser(UserInterface ui) {

		// Get the set of intermediate variable, which should contain all
		// variables other than the evidence variables for which we
		// want to calculate the most likely input.
		this.intermediate = ui.getIntermediateVariables();

		// Create the factors.
		this.factors = new ArrayList<>();
		for (Table t : ui.getPs()) {
			factors.add(new Factor(t.getVariable(), t.getTable()));
		}
		ui.setFs(new ArrayList<>(factors));

		// Set the heuristic.
		this.heuristic = "2"; // 2 is fewest-factor, 1 is least-incoming
	}

	/**
	 * ~~~~~~~~~~THIS SECTION IS FOR THE INPUT CALCULATION~~~~~~~~~~
	 */

	/**
	 * A function which calculates the marginal prior probabilities for joint value
	 * assignments to a set of evidence variables (which is defined in the
	 * constructor of the UserInterface class). The value assignments and their
	 * probabilities are printed to the .txt file "optimalInput.txt".
	 */
	public void calculateEvidenceInput() {

		// Decide on an elimination ordering for the intermediate variables.
		Heuristic h = new Heuristic(this.heuristic);
		List<Variable> order = h.apply(this.intermediate, this.factors);

		// Eliminate the intermediate variables one by one.
		for (int i = 0; i < order.size(); i++) {
			eliminateVariable(order.get(i));
			intermediate.remove(order.get(i));
		}

		// Multiply all remaining factors, so we are left with a single factor which
		// contains all the information we need.
		Factor totalFactor = this.factors.remove(0);
		while (!this.factors.isEmpty()) {
			Factor otherFactor = this.factors.remove(0);
			System.gc();
			if (totalFactor.size() > otherFactor.size()) {
				totalFactor = totalFactor.product(otherFactor);
			} else {
				totalFactor = otherFactor.product(totalFactor);
			}
		}
		
		// NOTE: 
		// Assuming we calculate the entire input for the ALARM network (all 16 evidence
		// variables), f1.product(f2) identifies the final factor-calculation.
		// If this is identified, we avoid memory overflow by only saving the top 100
		// most likely value assignments (rather than all ~45.35 million).
		// These are then ordered on probability (descending). 
		// Their probabilities are still normalised properly.

		// Print the output to a file
		PrintWriter toFile;
		try {
			toFile = new PrintWriter("optimalInput.txt");
			toFile.println(totalFactor);
			toFile.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ~~~~~~~~~~THIS SECTIONIS FOR ALL OTHER FUNCTIONS~~~~~~~~~~
	 */

	/**
	 * This function eliminates a given variable from all the factors containing it.
	 * First it checks which factors contain the variable. If more than two factors
	 * contain the variable they will be multiplied together according to the
	 * multiply function in Factor. Lastly the variable will be marginalised and
	 * therefore eliminated. If the resulting factors still contains variables, it
	 * will be added to the factors list again as a new factor.
	 *
	 * @param var, variable to eliminate
	 */
	private void eliminateVariable(Variable var) {
		// Check in which factors the variable is contained and add those to a new
		// ArrayList.
		List<Factor> containVar = containedIn(var, factors);
		if (!containVar.isEmpty()) {
			// Multiply the factors that contain the variable until there is only one factor
			// left.
			Factor res = containVar.remove(0);
			while (!containVar.isEmpty()) {
				Factor otherFactor = containVar.remove(0);
				System.gc();
				if (res.size() > otherFactor.size()) {
					res = res.product(otherFactor);
				} else {
					res = otherFactor.product(res);
				}
			}
			// Marginalise the variable out of the resulting factor. 
			Factor result = res.marginalize(var);
			System.gc();

			// If the resulting factor is not empty, add it to Factors.
			if (result.NrOfVariables() > 0) {
				factors.add(result);
			}
		}
	}

	/**
	 * This function checks in which factors the variable is contained. It adds
	 * those to a new ArrayList, and removes them from the list given in the input.
	 *
	 * @param v
	 * @param factors
	 * @return an List of factors in which variable v is contained.
	 */
	private List<Factor> containedIn(Variable v, List<Factor> factors) {
		List<Factor> containVar = new ArrayList<>();
		Iterator<Factor> it = factors.iterator();
		// Check in which factors the variable is contained and add those to a new
		// ArrayList.
		while (it.hasNext()) {
			Factor factor = it.next();
			if (factor.containsVar(v)) {
				containVar.add(factor);
				it.remove();
			}
		}
		return containVar;
	}
}
