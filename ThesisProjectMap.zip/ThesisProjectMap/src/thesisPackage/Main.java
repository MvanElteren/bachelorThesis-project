package thesisPackage;

import java.util.*;

/**
 * Main class, originally used to read in a network, define queries and observed variables, and run
 * variable elimination.
 * 
 * Updated so it can be used to calculate the most likely input to the ALARM network,
 * or to calculate quantified MAP-dependence and intrinsic relevance over some input to the ALARM network.
 * 
 * @author Marcel de Korte, Moira Berens, Djamari Oetringer, Abdullahi Ali,
 *         Leonieke van den Bulk
 *         
 * Updated by @author Merlijn van Elteren
 */
public class Main {
	// .bif-files for other networks can be found on http://www.bnlearn.com/bnrepository/
	private final static String networkName = "alarm.bif";

	public static void main(String[] args) {
		
		// Read in the network
		Networkreader reader = new Networkreader(networkName);

		// Get the variables and probabilities of the network
		List<Variable> vs = reader.getVs();
		List<Table> ps = reader.getPs();
		
		// Set the values for the evidence variables.
		String[] valueAssignment = 
				 {"FALSE", "NORMAL", "HIGH", "NORMAL",
		          "NORMAL", "NORMAL", "NORMAL", "NORMAL",
		          "NORMAL", "NORMAL", "NORMAL", "NORMAL",
		          "NORMAL", "NORMAL", "NORMAL", "HIGH"};
		
		// Make user interface
		// End in "true" argument if you are calculating most likely input. Set "false" otherwise.
		UserInterface ui = new UserInterface(vs, ps, valueAssignment, false);
		
		// Enable the following lines when you wish to calculate the most likely input to the ALARM network.
//		InputOptimiser algorithm = new InputOptimiser(ui);
//		algorithm.calculateEviFactors();
		
		// Enable the following lines when you wish to calculate relevance values.
		RelevanceMeasurer algorithm = new RelevanceMeasurer(ui);
//		algorithm.solveMapIndependence();
//		System.out.println();
		algorithm.solveIntrinsicRelevance();
	}
}