package thesisPackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class that handles the communication with the user.
 *
 * @author Marcel de Korte, Moira Berens, Djamari Oetringer, Abdullahi Ali,
 *         Leonieke van den Bulk
 * 
 * Updated for application to my thesis project.
 * 
 * Updated by @author Merlijn van Elteren.
 */
public class UserInterface {

	private List<Variable> vs;
	List<Table> ps;
	List<Factor> fs;
	private List<Variable> hypVs;
	private List<Variable> eviVs;
	private List<Variable> intVs;
	private String line;
	private String heuristic;
	private Scanner scan;
	// networkName assumed to be "alarm.bif";

	/**
	 * Constructor of the user interface.
	 *
	 * @param vs, the list of variables.
	 * @param ps, the list of probability tables.
	 * @param eviValueAssignment, an array of strings indicating the value assignment for each evidence variable.
	 * @param calcInput, a boolean indicating whether we are calculating the input (true) or not (false) 
	 */
	public UserInterface(List<Variable> vs, List<Table> ps, String[] eviValueAssignment, boolean calcInput) {
		this.vs = vs;
		this.ps = ps;
		// It is assumed that we are working on the ALARM network.

		// When calculating the most likely input, eviVs is the hypothesis set and the
		// rest is all intermediate.
		if (calcInput) {
			hypVs = new ArrayList<>();
			intVs = new ArrayList<>();
			int[] hypIndices = {};
			// At max contains { 0, 1, 2, 8, 9, 11, 14, 15, 17, 18, 20, 21, 25, 27, 35, 36 }
			int[] notHypIndices = { 0, 1, 2, 8, 9, 11, 14, 15, 17, 18, 20, 21, 27, 35, 36 };
			int[] intIndices = { 3, 4, 5, 6, 7, 10, 12, 13, 16, 19, 22, 23, 24, 26, 28, 29, 30, 31, 32, 33, 34 };
			// At least contains { 3, 4, 5, 6, 7, 10, 12, 13, 16, 19, 22, 23, 24, 26, 28,
			// 29, 30, 31, 32, 33, 34 }
			for (int index : hypIndices) {
				hypVs.add(vs.get(index));
			}
			for (int index : notHypIndices) {
				intVs.add(vs.get(index));
			}
			for (int index : intIndices) {
				intVs.add(vs.get(index));
			}
			// Otherwise, we are calculating relevance values over some input.
		} else {
			hypVs = new ArrayList<>();
			int[] hypIndices = { 3, 5, 12, 13, 16, 22, 24, 26 };
			for (int index : hypIndices) {
				hypVs.add(vs.get(index));
			}

			eviVs = new ArrayList<>();
			int[] eviIndices = { 0, 1, 2, 8, 9, 11, 14, 15, 17, 18, 20, 21, 25, 27, 35, 36 };
			for (int index : eviIndices) {
				eviVs.add(vs.get(index));
			}
			this.setEvidenceValues(eviValueAssignment);

			intVs = new ArrayList<>();
			int[] intIndices = { 4, 6, 7, 10, 19, 23, 28, 29, 30, 31, 32, 33, 34 };
			for (int index : intIndices) {
				intVs.add(vs.get(index));
			}
		}
	}

	/**
	 * Setter of the factors that are displayed in the user interface
	 *
	 * @param newFs
	 */
	public void setFs(List<Factor> newFs) {
		this.fs = newFs;
	}

	/**
	 * Setter of the variables that are displayed in the user interface
	 *
	 * @param newVs
	 */
	public void setVs(List<Variable> newVs) {
		this.vs = newVs;
	}

	/**
	 * Sets the values of the evidence variables to the given values.
	 * 
	 * @param values, an array of strings indicating the value for each evidence variable.
	 */
	public void setEvidenceValues(String[] values) {
		for (int i = 0; i < values.length; i++) {
			changeVariableToObserved(i, values[i]);
		}
	}

	/**
	 * Checks whether a number and value represent a valid observed value or not.
	 * If so, adds it to the observed list. If not, asks again for new input.
	 * 
	 * @param queriedVar, a number indicating the index in eviVs of the queried variable.
	 * @param value, a string indicating the given observed value.
	 */
	public void changeVariableToObserved(int queriedVar, String value) {
		Variable ob;
		if (queriedVar >= 0 && queriedVar < eviVs.size()) {
			ob = eviVs.get(queriedVar);
			if (ob.canTakeValue(value)) {
				ob.setObservedValue(value);
				ob.setObserved(true);
			} else {
				System.out.println("Apparently you did not fill in a value correctly. You entered: \"" + value
						+ "\"Please try again");
				return;
			}
		}
	}

	/**
	 * Prints the probability tables of a list fs of factors, by
	 * printing the variable and associated table.
	 * 
	 * @param fs, a list of factors.
	 */
	public String printFactors(List<Factor> fs) {
		String result = "";
		for (int i = 0; i < fs.size(); i++) {
			// Print the factors variable names
			result += fs.get(i).shortString();
			System.out.println(fs.get(i).shortString());

			// Get the factor and print all probability rows for the table of that factor.
			Factor probs = fs.get(i);
			for (int l = 0; l < probs.size(); l++) {
				result += "\n" + probs.get(l);
				System.out.println(probs.get(l)); // Printing
			}
			result += "\n\n"; // the
			System.out.println(); // probabilities.
		}
		return result;
	}

	/**
	 * Prints the formula of each factor in the network.
	 * 
	 * @return String of formula for factors in the network.
	 */
	public String printFormula() {
		String result = "";
		for (int i = 0; i < fs.size(); i++) {
			result = result + fs.get(i).shortString() + " ";
		}
		System.out.println(result);
		return result;
	}

	/**
	 * Prints the network that was read-in (by printing the variables, parents and
	 * probabilities).
	 *
	 * @param The list of variables.
	 * @param The list of probabilities.
	 */
	public void printNetwork() {
		System.out.println("The variables:");
		for (int i = 0; i < vs.size(); i++) {
			String values = "";
			for (int j = 0; j < vs.get(i).getNrOfValues() - 1; j++) {
				values = values + vs.get(i).getValues().get(j) + ", ";
			}
			values = values + vs.get(i).getValues().get(vs.get(i).getNrOfValues() - 1);
			System.out.println((i + 1) + ") " + vs.get(i).getName() + " - " + values); // Printing
			// the
			// variables.
		}
		System.out.println("\nThe probabilities:");
		for (int i = 0; i < ps.size(); i++) {
			if (vs.get(i).getNrOfParents() == 1) {
				System.out.println(
						ps.get(i).getVariable().getName() + " has parent " + vs.get(i).getParents().get(0).getName());
			} else if (vs.get(i).getNrOfParents() > 1) {
				String parentsList = "";
				for (int j = 0; j < vs.get(i).getParents().size(); j++) {
					parentsList = parentsList + vs.get(i).getParents().get(j).getName();
					if (!(j == vs.get(i).getParents().size() - 1)) {
						parentsList = parentsList + " and ";
					}
				}
				System.out.println(ps.get(i).getVariable().getName() + " has parents " + parentsList);
			} else {
				System.out.println(ps.get(i).getVariable().getName() + " has no parents.");
			}

			Table probs = ps.get(i);
			for (int l = 0; l < probs.size(); l++) {
				System.out.println(probs.get(l)); // Printing
			} // the
			System.out.println(); // probabilities.
		}
	}

	/**
	 * Prints the query and observed variables given in by the user.
	 *
	 * @param The query variable(s).
	 * @param The observed variable(s).
	 */
	public void printHypothesisAndEvidence(List<Variable> queries, List<Variable> Obs) {
		System.out.println("\nThe queried variable(s) is/are: "); // Printing the queried variables.
		for (Variable query : queries) {
			System.out.println(query.getName());
		}
		if (!Obs.isEmpty()) {
			System.out.println("The observed variable(s) is/are: "); // Printing
			// the
			// observed
			// variables.
			for (int m = 0; m < Obs.size(); m++) {
				System.out.println(Obs.get(m).getName());
				System.out.println("This variable has the value: " + Obs.get(m).getObservedValue());
			}
		}
	}

	/**
	 * Asks the user to indicate which heuristic they want to use.
	 */
	public void askForHeuristic() {
		System.out.println("Supply a heuristic. Input 1 for least-incoming, 2 for fewest-factors and enter for random");
		scan = new Scanner(System.in);
		line = scan.nextLine();
		if (line.isEmpty()) {
			heuristic = "empty";
			System.out.println("You have chosen for the random heuristic");
		} else if (line.equals("1")) {
			heuristic = "least-incoming";
			System.out.println("You have chosen for the least-incoming heuristic");
		} else if (line.equals("2")) {
			heuristic = "fewest-factors";
			System.out.println("You have chosen for the fewest-factors heuristic");
		} else {
			System.out.println(line + " is not an option. Please try again");
			askForHeuristic();
		}
		scan.close();
	}

	/**
	 * Getter of the evidence variables.
	 *
	 * @return a list of evidence variables.
	 */
	public List<Variable> getEvidenceVariables() {
		return eviVs;
	}

	/**
	 * Getter of the hypothesis variables.
	 *
	 * @return a list of hypothesis variables.
	 */
	public List<Variable> getHypothesisVariables() {
		return hypVs;
	}

	/**
	 * Getter of the intermediate variables.
	 *
	 * @return a list of intermediate variables.
	 */
	public List<Variable> getIntermediateVariables() {
		return intVs;
	}

	/**
	 * Getter of the heuristic.
	 *
	 * @return the name of the heuristic.
	 */
	public String getHeuristic() {
		return heuristic;
	}

	public List<Variable> getVs() {
		return this.vs;
	}

	public List<Table> getPs() {
		return this.ps;
	}
}
