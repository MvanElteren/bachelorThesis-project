package thesisPackage;

import java.util.ArrayList;
import java.util.List;

/**
 * Class to represent a probability table consisting of probability rows.
 *
 * @author Marcel de Korte, Moira Berens, Djamari Oetringer, Abdullahi Ali,
 *         Leonieke van den Bulk
 */
public class Table {

	private Variable variable;
	private List<ProbRow> table;

	/**
	 * Constructor of the class.
	 * 
	 * @param variable, variable belonging to the current probability table.
	 * @param table,    table made out of probability rows (ProbRows).
	 */
	public Table(Variable variable, List<ProbRow> table) {
		this.variable = variable;
		this.table = table;
	}

	public Table() {
	}

	/**
	 * Returns the size of the Table (amount of probability rows).
	 * 
	 * @return amount of rows in the table as an int.
	 */
	public int size() {
		return table.size();
	}

	/**
	 * Transform table to string.
	 */
	public String toString() {
		String tableString = variable.getName() + " | ";
		for (int i = 0; i < variable.getNrOfParents(); i++) {
			tableString = tableString + variable.getParents().get(i).getName();
			if (!(i == variable.getNrOfParents() - 1)) {
				tableString = tableString + ", ";
			}
		}
		for (ProbRow row : table) {
			tableString = tableString + "\n" + row.toString();
		}
		return tableString;
	}

	/**
	 * Gets the i'th element from the List of ProbRows.
	 * 
	 * @param i index as an int.
	 * @return i'th ProbRow in Table.
	 */
	public ProbRow get(int i) {
		return table.get(i);
	}

	/**
	 * Getter of the table made out of ProbRows
	 * 
	 * @return table as an List of ProbRows.
	 */
	public List<ProbRow> getTable() {
		return table;
	}

	/**
	 * Creates a copy of the table of ProbRows.
	 * 
	 * @return table as an List of ProbRows.
	 */
	public List<ProbRow> getTableCopy() {
		List<ProbRow> rows = new ArrayList<>();
		for (ProbRow row : getTable()) {
			rows.add(row.getCopy());
		}
		return rows;
	}

	/**
	 * This function updates a table to the new given table made out of ProbRows.
	 * 
	 * @param table
	 */
	public void setTable(List<ProbRow> table) {
		this.table = table;
	}

	/**
	 * Getter of the variable that belongs to the probability table.
	 * 
	 * @return the variable.
	 */
	public Variable getVariable() {
		return variable;
	}

	/**
	 * Setter of the variable that belongs to the probability table.
	 * 
	 * @param v
	 */
	public void setVariable(Variable v) {
		this.variable = v;
	}

	/**
	 * Getter of the parents that belong to the node of the probability table.
	 * 
	 * @return the parents as an List of Variables.
	 */
	public List<Variable> getParents() {
		return variable.getParents();
	}
}
