package thesisPackage;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Class that orders the variables in a list according to the
 * least-incoming-arcs or contained-in-fewest-factors heuristic
 *
 * @author Simon Janssen and Jonathan Bauermeister
 */
public class Heuristic {

	private String heuristic;

	/**
	 * Constructor of the class.
	 * 
	 * @param heuristic, heuristic that has to be applied
	 */
	public Heuristic(String heuristic) {
		this.heuristic = heuristic;
	}

	/**
	 * This function applies the given heuristic to the variable list in order to
	 * order them. If the heuristic was contained-in-fewest-factors, the function
	 * will return the result of that particular function. In all other cases, the
	 * function will return the heuristic least-incoming-arcs.
	 * 
	 * @param variables
	 * @param factors
	 * @return updated list of variables: ordering based on heuristic
	 */
	public List<Variable> apply(List<Variable> variables, List<Factor> factors) {
		switch (this.heuristic) {
		case "fewest-factors":
			return fewestFactorHeuristic(variables, factors);
		default:
			return leastIncomingHeuristic(variables);
		}
	}

	/**
	 * This function computes how many factors contain the given variable and
	 * returns the result.
	 * 
	 * @param variable
	 * @param factors
	 * @return the number of factors in which the given variable is contained.
	 */
	private Integer calculateAmountOfFactors(Variable variable, List<Factor> factors) {
		int result = 0;
		for (Factor f : factors) {
			if (f.containsVar(variable)) {
				result++;
			}
		}
		return result;
	}

	/**
	 * This function determines the ordering of the variables based on the
	 * contained-in-fewest-factors heuristic.
	 *
	 * @param variables
	 * @param factors
	 * @return new ordering of variables.
	 */
	private List<Variable> fewestFactorHeuristic(List<Variable> variables, List<Factor> factors) {
		Map<Variable, Integer> map = new HashMap<Variable, Integer>();
		for (int i = 0; i < variables.size(); i++) {
			Variable var = variables.get(i);
			// calculate the amount of factors the variable is in, and add it to the map
			// together with the variable.
			map.put(var, calculateAmountOfFactors(var, factors));
		}
		// Create a new variable list and add the first variable to the list.
		List<Variable> order = new ArrayList<>();
		if (!variables.isEmpty()) {
			order.add(variables.get(0));
			for (int i = 1; i < variables.size(); i++) {
				Variable v = variables.get(i);
				// Add a variable that checks if the variable is already added to the list.
				boolean added = false;
				for (int j = 0; j < i; j++) {
					// For every position in the newly created list, check whether the variable is
					// in
					// less factors than the variable at that position in the new ArrayList.
					if (map.get(v) < map.get(order.get(j)) && !added) {
						// If it is, add the variable to that position and move the rest one place up.
						order.add(j, v);
						// Set the boolean to true and continue with the function.
						added = true;
						continue;
					}
				}
				// If the variable is compared to all other variables in the new ArrayList, but
				// the amount of factors that it is
				// in is higher than that of the other variables, then add the variable to the
				// end of the list.
				if (!added) {
					order.add(v);
				}
			}
		}
		// Return the new ArrayList with the correct ordering.
		return order;
	}

	/**
	 * This function determines the ordering of the variables based on the
	 * least-incoming-arcs heuristic.
	 *
	 * @param variables
	 * @return new ordering of the variables.
	 */
	private List<Variable> leastIncomingHeuristic(List<Variable> variables) {
		// Create a new variable list and add the first variable to the list.
		List<Variable> order = new ArrayList<>();
		if (!variables.isEmpty()) {
			order.add(variables.get(0));
			for (int i = 1; i < variables.size(); i++) {
				Variable var = variables.get(i);
				// Add a variable that checks whether the variable is already added to the list.
				boolean added = false;
				for (int j = 0; j < order.size(); j++) {
					// For every position in the newly created list, check whether the variable has
					// less parents
					// than the variable at that position in the new ArrayList.
					if (var.getNrOfParents() < order.get(j).getNrOfParents() && !added) {
						// If it has less parents, add the variable to that position and move the
						// variables with more parents
						// one place up.
						order.add(j, variables.get(i));
						// Set the boolean to true and continue with the function.
						added = true;
						continue;
					}
				}
				// If the variable is compared to all other variables in the new ArrayList, but
				// the amount of parents that it has
				// is higher than that of the other variables, then add the variable to the end
				// of the list.
				if (!added) {
					order.add(var);
				}
			}
		}
		// Return the new ArrayList with the correct ordering.
		return order;
	}
}
